import React, { useState, useEffect } from 'react';
import { Property } from '@/api/entities';
import { BlogPost } from '@/api/entities';
import { ServiceCategory } from '@/api/entities';

const generateSitemap = (properties, posts, categories) => {
    const baseUrl = 'https://arriendospuertovaras.cl';
    const today = new Date().toISOString();

    const staticPages = [
        '/',
        '/arriendos',
        '/servicios',
        '/blog',
        '/contacto',
        '/quienes-somos',
        '/proximamente',
        '/ayuda'
    ];

    const sitemapContent = `
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
    ${staticPages.map(page => `
    <url>
        <loc>${baseUrl}${page}</loc>
        <lastmod>${today}</lastmod>
        <changefreq>weekly</changefreq>
        <priority>0.8</priority>
    </url>`).join('')}
    
    ${properties.map(prop => `
    <url>
        <loc>${baseUrl}/PropertyDetail?id=${prop.id}</loc>
        <lastmod>${new Date(prop.updated_date || prop.created_date).toISOString()}</lastmod>
        <changefreq>daily</changefreq>
        <priority>1.0</priority>
    </url>`).join('')}
    
    ${posts.map(post => `
    <url>
        <loc>${baseUrl}/BlogPostDetail?slug=${post.slug}</loc>
        <lastmod>${new Date(post.updated_date || post.created_date).toISOString()}</lastmod>
        <changefreq>monthly</changefreq>
        <priority>0.7</priority>
    </url>`).join('')}

    ${categories.map(cat => `
    <url>
        <loc>${baseUrl}/ServiceCategoryDetail?slug=${cat.slug}</loc>
        <lastmod>${today}</lastmod>
        <changefreq>weekly</changefreq>
        <priority>0.6</priority>
    </url>`).join('')}
</urlset>
    `.trim();

    return sitemapContent;
};

export default function SitemapPage() {
    const [sitemapXml, setSitemapXml] = useState('');

    useEffect(() => {
        const fetchAndGenerate = async () => {
            try {
                const [properties, posts, categories] = await Promise.all([
                    Property.filter({ status: 'activa' }),
                    BlogPost.filter({ status: 'published' }),
                    ServiceCategory.filter({ active: true })
                ]);
                const xml = generateSitemap(properties, posts, categories);
                setSitemapXml(xml);
            } catch (error) {
                console.error("Error generating sitemap:", error);
                setSitemapXml('<error>Could not generate sitemap</error>');
            }
        };

        fetchAndGenerate();
    }, []);

    // This component is intended to be used by a serverless function
    // that sets the Content-Type header to 'application/xml'.
    // In a pure frontend app, we display it for verification.
    return (
        <div style={{ whiteSpace: 'pre', fontFamily: 'monospace', padding: '20px' }}>
            {sitemapXml || 'Generating sitemap...'}
        </div>
    );
}