import { siteStructure } from "@/components/utils/sitemapData";

/**
 * Genera un sitemap en formato XML estándar para buscadores.
 * @returns {string} - El contenido del archivo sitemap.xml.
 */
export const generateXMLSitemap = () => {
  const origin = window.location.origin;
  const today = new Date().toISOString();

  let xml = `<?xml version="1.0" encoding="UTF-8"?>\n`;
  xml += `<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n`;

  const addUrl = (page, priority, changefreq = 'monthly') => {
    // Omite páginas que no deben ser indexadas (con parámetros de ID)
    if (page.url.includes(':id') || page.url.includes(':slug')) {
      return; 
    }
    const fullUrl = `${origin}${page.url}`;
    
    xml += `  <url>\n`;
    xml += `    <loc>${fullUrl}</loc>\n`;
    xml += `    <lastmod>${today}</lastmod>\n`;
    xml += `    <changefreq>${changefreq}</changefreq>\n`;
    xml += `    <priority>${priority.toFixed(1)}</priority>\n`;
    xml += `  </url>\n`;
  };

  // Asigna prioridades y frecuencias de cambio según la importancia de la página
  Object.values(siteStructure.mainPages).forEach(page => addUrl(page, 1.0, 'daily'));
  Object.values(siteStructure.detailPages).forEach(page => addUrl(page, 0.9, 'weekly'));
  Object.values(siteStructure.userManagement).forEach(page => addUrl(page, 0.5, 'yearly')); // Menos importante para SEO
  Object.values(siteStructure.hostManagement).forEach(page => addUrl(page, 0.5, 'yearly')); // Menos importante para SEO
  Object.values(siteStructure.specialFeatures).forEach(page => addUrl(page, 0.8, 'weekly'));
  Object.values(siteStructure.contentPages).forEach(page => addUrl(page, 0.7, 'weekly'));
  Object.values(siteStructure.professionalServices).forEach(page => addUrl(page, 0.8, 'weekly'));
  Object.values(siteStructure.legalPages).forEach(page => addUrl(page, 0.3, 'yearly'));

  xml += `</urlset>`;
  return xml;
};