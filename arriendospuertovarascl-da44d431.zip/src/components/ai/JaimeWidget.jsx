// Widget eliminado completamente - solo existe el botón del header
import React from 'react';

export default function JaimeWidget() {
  // Component completamente vacío - el widget flotante ha sido eliminado
  // Solo debe existir el botón en el header
  return null;
}