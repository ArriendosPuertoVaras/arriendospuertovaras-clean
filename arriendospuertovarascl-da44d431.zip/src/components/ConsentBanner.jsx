'use client';
import { useEffect, useState } from 'react';

const GA_ID = 'G-9ZGG23T6WF';

export default function ConsentBanner() {
  // Siempre retornar null para ocultar el banner
  return null;
}